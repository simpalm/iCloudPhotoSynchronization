//
//  ObjectClass.m
//  MapKitDragAndDrop
//
//  Created by VMFactor on 6/4/13.
//
//

#import "ObjectClass.h"

@implementation ObjectClass

@synthesize m_object;
@synthesize mapView;
@synthesize m_imageview;

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code]
        
        
    }
    return self;
}

- (void)initialize
{
    UIPanGestureRecognizer* pgr = [[UIPanGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(handlePan:)];
    [m_object addGestureRecognizer:pgr];
    [pgr release];
}

-(void)handlePan:(UIPanGestureRecognizer*)pgr;
{
    if (pgr.state == UIGestureRecognizerStateChanged)
    {
        CGPoint center = pgr.view.center;
        CGPoint translation = [pgr translationInView:pgr.view];
        center = CGPointMake(center.x + translation.x,
                             center.y + translation.y);
        pgr.view.center = center;
        [pgr setTranslation:CGPointZero inView:pgr.view];
        //end = pgr.view.center;
        
        /*CGPoint newCenter;
         newCenter.x = self.originalCenter.x + (end.x - self.startLocation.x);
         newCenter.y = self.originalCenter.y + (end.y - self.startLocation.y);
         
         DDAnnotation *theAnnotation = (DDAnnotation *)[self.mapView.annotations objectAtIndex:0];
         CLLocationCoordinate2D newCoordinate = [self.mapView convertPoint:newCenter toCoordinateFromView:self.view];
         [theAnnotation setCoordinate:newCoordinate];
         [mapView addAnnotation:theAnnotation];*/
        
       m_imageview.image = [self drawLineFromPoint:CGPointMake(40, 40) toPoint:pgr.view.center image:m_imageview.image];
       // [self setNeedsDisplay];
    }
}



// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    [super drawRect:rect];
    // Drawing code
    /*context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth(context, 2.0);
    CGContextMoveToPoint(context, 0, 0.0);
    CGContextAddLineToPoint(context, 120.0, 150.0); CGContextStrokePath(context);
    
    CGContextStrokePath(context);*/
}

- (UIImage *)drawLineFromPoint:(CGPoint)fromPoint toPoint:(CGPoint)toPoint image:(UIImage *)image
{
    CGSize screenSize = self.frame.size;
    UIGraphicsBeginImageContext(screenSize);
    CGContextRef currentContext = UIGraphicsGetCurrentContext();
    [image drawInRect:CGRectMake(0, 0, screenSize.width, screenSize.height)];
   // [self drawRect:CGRectMake(0, 0, screenSize.width, screenSize.height)];
    
    CGContextClearRect(currentContext, CGRectMake(0, 0, screenSize.width, screenSize.height));
    CGContextSetLineCap(currentContext, kCGLineCapRound);
    CGContextSetLineWidth(currentContext, 2.0);
    CGContextSetRGBStrokeColor(currentContext, 0, 0, 0, 1);
    CGContextBeginPath(currentContext);
    CGContextMoveToPoint(currentContext, fromPoint.x, fromPoint.y);
    CGContextAddLineToPoint(currentContext, toPoint.x, toPoint.y);
    CGContextStrokePath(currentContext);
    
    UIImage *ret = UIGraphicsGetImageFromCurrentImageContext();
    
   /// UIView *view = (UIView *)ret;
    //self  = (ObjectClass)view;
    UIGraphicsEndImageContext();
    
    return ret;
}

@end
