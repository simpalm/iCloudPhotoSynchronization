//
//  MapKitDragAndDropViewController.h
//  MapKitDragAndDrop
//
//  Created by digdog on 11/1/10.
//  Copyright 2010 Ching-Lan 'digdog' HUANG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
#import "ObjectClass.h"

@interface MapKitDragAndDropViewController : UIViewController <MKMapViewDelegate> {
	MKMapView *mapView;
    
    MKPolyline* _routeLine;
    MKPolylineView* _routeLineView;
    MKMapRect _routeRect;
    
    CLLocationCoordinate2D oldLocation;
    CLLocationCoordinate2D newLocation;
    
    
    BOOL isMoving_;
	CGPoint startLocation_;
	CGPoint originalCenter_;
	UIImageView *pinShadow_;
	NSTimer *pinTimer_;
    
    CGPoint start;
	CGPoint end;
    
    float oldX, oldY;
    BOOL dragging;
}

@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) IBOutlet UIView *m_object;
@property (nonatomic, retain) IBOutlet ObjectClass *m_view;

@property (nonatomic, retain) MKPolyline* routeLine;
@property (nonatomic, retain) MKPolylineView* routeLineView;


@property (nonatomic, assign) BOOL isMoving;
@property (nonatomic, assign) CGPoint startLocation;
@property (nonatomic, assign) CGPoint originalCenter;

@property (nonatomic, retain) UIImageView *	pinShadow;
@property (nonatomic, retain) NSTimer * pinTimer;


@end

