//
//  ObjectClass.h
//  MapKitDragAndDrop
//
//  Created by VMFactor on 6/4/13.
//
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface ObjectClass : UIView
{
    CGContextRef context;
}

@property (nonatomic, retain) IBOutlet UIView *m_object;
@property (nonatomic, retain) IBOutlet MKMapView *mapView;
@property (nonatomic, retain) IBOutlet UIImageView *m_imageview;

- (void)drawLine:(CGPoint)start endpoint:(CGPoint)end;
- (void)initialize;
@end
