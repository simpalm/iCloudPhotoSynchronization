//
//  MapKitDragAndDropViewController.m
//  MapKitDragAndDrop
//
//  Created by digdog on 11/1/10.
//  Copyright 2010 Ching-Lan 'digdog' HUANG. All rights reserved.
//

#import "MapKitDragAndDropViewController.h"
#import "DDAnnotation.h"
#import "DDAnnotationView.h"


@interface MapKitDragAndDropViewController () 
- (void)coordinateChanged_:(NSNotification *)notification;
@end

@implementation MapKitDragAndDropViewController

@synthesize mapView;

@synthesize routeLine = _routeLine;
@synthesize routeLineView = _routeLineView;


@synthesize isMoving = isMoving_;
@synthesize startLocation = startLocation_;
@synthesize originalCenter = originalCenter_;
@synthesize pinShadow = pinShadow_;
@synthesize pinTimer = pinTimer_;


@synthesize m_object;
@synthesize m_view;

- (id)getViewFromXib:(NSString *)sNibName classname:(Class)ClassName
{
	id View = nil;
	NSArray *arrViews = [[NSBundle mainBundle] loadNibNamed:sNibName owner:nil options:nil];
	for(id view in arrViews)
	{
		if([view isKindOfClass:ClassName])
		{
			View = view;
		}
	}
	return View;
}


// Implement viewDidLoad to do additional setup after loading the view, typically from a nib.
- (void)viewDidLoad {
    [super viewDidLoad];
	
	CLLocationCoordinate2D theCoordinate;
	theCoordinate.latitude = 37.810000;
    theCoordinate.longitude = -122.477989;
    
    oldLocation = theCoordinate;
	
	DDAnnotation *annotation = [[[DDAnnotation alloc] initWithCoordinate:theCoordinate addressDictionary:nil] autorelease];
	annotation.title = @"Drag to Move Pin";
	annotation.subtitle = [NSString	stringWithFormat:@"%f %f", annotation.coordinate.latitude, annotation.coordinate.longitude];
    
    start = CGPointMake(40, 40);
	
	[self.mapView addAnnotation:annotation];
    
    
    /*UIPanGestureRecognizer* pgr = [[UIPanGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(handlePan:)];
    [m_object addGestureRecognizer:pgr];
    [pgr release];*/
    
    ObjectClass *object = [self getViewFromXib:@"ObjectClass" classname:[ObjectClass class]];
    object.frame = CGRectMake(0, 0, 320, 460);
    [object initialize];
	[self.view addSubview:object];
	[object release];
}

-(void)handlePan:(UIPanGestureRecognizer*)pgr;
{
    if (pgr.state == UIGestureRecognizerStateChanged)
    {
        CGPoint center = pgr.view.center;
        CGPoint translation = [pgr translationInView:pgr.view];
        center = CGPointMake(center.x + translation.x,
                             center.y + translation.y);
        pgr.view.center = center;
        [pgr setTranslation:CGPointZero inView:pgr.view];
        end = pgr.view.center;
        
        /*CGPoint newCenter;
        newCenter.x = self.originalCenter.x + (end.x - self.startLocation.x);
		newCenter.y = self.originalCenter.y + (end.y - self.startLocation.y);
		
		DDAnnotation *theAnnotation = (DDAnnotation *)[self.mapView.annotations objectAtIndex:0];
        CLLocationCoordinate2D newCoordinate = [self.mapView convertPoint:newCenter toCoordinateFromView:self.view];
        [theAnnotation setCoordinate:newCoordinate];
        [mapView addAnnotation:theAnnotation];*/
        
        [self drawLine:start endpoint:end];
    }
}



- (void)drawLine:(CGPoint)startpoint endpoint:(CGPoint)endpoint
{
    CGContextSetStrokeColorWithColor(UIGraphicsGetCurrentContext(), [UIColor blackColor].CGColor);
    CGContextSetLineWidth(UIGraphicsGetCurrentContext(), 2.0);
    CGContextMoveToPoint(UIGraphicsGetCurrentContext(), startpoint.x, startpoint.y);
    CGContextAddLineToPoint(UIGraphicsGetCurrentContext(), endpoint.x, endpoint.y); CGContextStrokePath(UIGraphicsGetCurrentContext());
    
    CGContextStrokePath(UIGraphicsGetCurrentContext());
}


- (void)viewWillAppear:(BOOL)animated {
	
	[super viewWillAppear:animated];
	
	// NOTE: This is optional, DDAnnotationCoordinateDidChangeNotification only fired in iPhone OS 3, not in iOS 4.
	[[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(coordinateChanged_:) name:@"DDAnnotationCoordinateDidChangeNotification" object:nil];
}

- (void)viewWillDisappear:(BOOL)animated {
	
	[super viewWillDisappear:animated];
	
	// NOTE: This is optional, DDAnnotationCoordinateDidChangeNotification only fired in iPhone OS 3, not in iOS 4.
	[[NSNotificationCenter defaultCenter] removeObserver:self name:@"DDAnnotationCoordinateDidChangeNotification" object:nil];	
}

// Override to allow orientations other than the default portrait orientation.
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation {
	return YES;
}

- (void)didReceiveMemoryWarning {
	// Releases the view if it doesn't have a superview.
    [super didReceiveMemoryWarning];
	
	// Release any cached data, images, etc that aren't in use.
}

- (void)viewDidUnload {
	// Release any retained subviews of the main view.
	// e.g. self.myOutlet = nil;
	
	self.mapView.delegate = nil;
	self.mapView = nil;
}

- (void)dealloc {
	mapView.delegate = nil;
	[mapView release];
    
    [pinShadow_ release];
	
	[pinTimer_ invalidate];
	[pinTimer_ release];
    [super dealloc];
}


#pragma mark -
#pragma mark DDAnnotationCoordinateDidChangeNotification

// NOTE: DDAnnotationCoordinateDidChangeNotification won't fire in iOS 4, use -mapView:annotationView:didChangeDragState:fromOldState: instead.
- (void)coordinateChanged_:(NSNotification *)notification {
	
	DDAnnotation *annotation = notification.object;
	annotation.subtitle = [NSString	stringWithFormat:@"%f %f", annotation.coordinate.latitude, annotation.coordinate.longitude];
}

// creates the route (MKPolyline) overlay
-(void) loadRoute
{
    NSString *sfirst = [NSString stringWithFormat:@"%f,%f", oldLocation.latitude, oldLocation.longitude];
    NSString *ssec = [NSString stringWithFormat:@"%f,%f", newLocation.latitude, newLocation.longitude];

	NSArray* pointStrings = [[NSArray alloc] initWithObjects:sfirst, ssec, nil];;
	
	
	// while we create the route points, we will also be calculating the bounding box of our route
	// so we can easily zoom in on it.
	MKMapPoint northEastPoint;
	MKMapPoint southWestPoint;
	
	// create a c array of points.
	MKMapPoint* pointArr = malloc(sizeof(CLLocationCoordinate2D) * pointStrings.count);
    pointArr[0] = MKMapPointForCoordinate(oldLocation);
    pointArr[1] = MKMapPointForCoordinate(newLocation);
    
    //CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);

	
	/*for(int idx = 0; idx < pointStrings.count; idx++)
	{
		// break the string down even further to latitude and longitude fields.
		NSString* currentPointString = [pointStrings objectAtIndex:idx];
		NSArray* latLonArr = [currentPointString componentsSeparatedByCharactersInSet:[NSCharacterSet characterSetWithCharactersInString:@","]];
        
		CLLocationDegrees latitude  = [[latLonArr objectAtIndex:0] doubleValue];
		CLLocationDegrees longitude = [[latLonArr objectAtIndex:1] doubleValue];
        
        
		// create our coordinate and add it to the correct spot in the array
		CLLocationCoordinate2D coordinate = CLLocationCoordinate2DMake(latitude, longitude);
        
		MKMapPoint point = MKMapPointForCoordinate(coordinate);
        
		
		//
		// adjust the bounding box
		//
		
		// if it is the first point, just use them, since we have nothing to compare to yet.
		if (idx == 0) {
			northEastPoint = point;
			southWestPoint = point;
		}
		else
		{
			if (point.x > northEastPoint.x)
				northEastPoint.x = point.x;
			if(point.y > northEastPoint.y)
				northEastPoint.y = point.y;
			if (point.x < southWestPoint.x)
				southWestPoint.x = point.x;
			if (point.y < southWestPoint.y)
				southWestPoint.y = point.y;
		}
        
		pointArr[idx] = point;
        
	}*/
	
	// create the polyline based on the array of points.
	_routeLine = [MKPolyline polylineWithPoints:pointArr count:pointStrings.count];
    
	//_routeRect = MKMapRectMake(southWestPoint.x, southWestPoint.y, northEastPoint.x - southWestPoint.x, northEastPoint.y - southWestPoint.y);
    
	// clear the memory allocated earlier for the points
	free(pointArr);
    
    // add the overlay to the map
	if (nil != self.routeLine)
    {
        [self.mapView removeOverlays:[self.mapView overlays]];
		[self.mapView addOverlay:self.routeLine];
	}
	
}


#pragma mark -
#pragma mark MKMapViewDelegate

- (void)mapView:(MKMapView *)mapView annotationView:(MKAnnotationView *)annotationView didChangeDragState:(MKAnnotationViewDragState)newState fromOldState:(MKAnnotationViewDragState)oldState {
	
	if (oldState == MKAnnotationViewDragStateDragging)
    {
        NSLog(@"Dragging1");
		DDAnnotation *annotation = (DDAnnotation *)annotationView.annotation;
		annotation.subtitle = [NSString	stringWithFormat:@"%f %f", annotation.coordinate.latitude, annotation.coordinate.longitude];
        newLocation = annotation.coordinate;
        //[self loadRoute];
        
	}
}

- (MKAnnotationView *)mapView:(MKMapView *)mapView viewForAnnotation:(id <MKAnnotation>)annotation {
	
    if ([annotation isKindOfClass:[MKUserLocation class]]) {
        return nil;		
	}
	static NSString * const kPinAnnotationIdentifier = @"PinIdentifier";
	MKAnnotationView *draggablePinView = [self.mapView dequeueReusableAnnotationViewWithIdentifier:kPinAnnotationIdentifier];

	if (draggablePinView)
    {
        NSLog(@"Dragging2");

		draggablePinView.annotation = annotation;
	}
    else
    {
        NSLog(@"Dragging3");

		// Use class method to create DDAnnotationView (on iOS 3) or built-in draggble MKPinAnnotationView (on iOS 4).
		draggablePinView = [DDAnnotationView annotationViewWithAnnotation:annotation reuseIdentifier:kPinAnnotationIdentifier mapView:self.mapView];
				
		if ([draggablePinView isKindOfClass:[DDAnnotationView class]]) {
			// draggablePinView is DDAnnotationView on iOS 3.
		} else {
			// draggablePinView instance will be built-in draggable MKPinAnnotationView when running on iOS 4.
		}
	}		
	
	return draggablePinView;
}

#pragma mark MKMapViewDelegate
- (MKOverlayView *)mapView:(MKMapView *)mapView viewForOverlay:(id <MKOverlay>)overlay
{
	MKOverlayView* overlayView = nil;
	
	if(overlay == self.routeLine)
	{
		//if we have not yet created an overlay view for this overlay, create it now.
		//if(nil == self.routeLineView)
		{
			self.routeLineView = [[[MKPolylineView alloc] initWithPolyline:self.routeLine] autorelease];
			self.routeLineView.fillColor = [UIColor redColor];
			self.routeLineView.strokeColor = [UIColor redColor];
			self.routeLineView.lineWidth = 3;
		}
		overlayView = self.routeLineView;
	}
	return overlayView;
	
}


#pragma mark -
#pragma mark Handling events


- (void)drawRect:(CGRect)rect
{
    [self.view drawRect:rect];
    // Drawing code
    CGContextRef context = UIGraphicsGetCurrentContext();
    CGContextSetStrokeColorWithColor(context, [UIColor blackColor].CGColor);
    CGContextSetLineWidth(context, 2.0);
    CGContextMoveToPoint(context, 0, 0.0);
    CGContextAddLineToPoint(context, 120.0, 150.0); CGContextStrokePath(context);
    
    CGContextStrokePath(context);
}

/*- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event
{
	
	CGPoint newlocation = [[touches anyObject] locationInView:self.view];
	CGPoint newCenter;
	
	// If the user's finger moved more than 5 pixels, begin the drag.
	if ((abs(newlocation.x - self.startLocation.x) > 5.0) || (abs(newlocation.y - self.startLocation.y) > 5.0)) {
		self.isMoving = YES;
	}
	
	// If dragging has begun, adjust the position of the view.
	if (self.mapView && self.isMoving)
    {
        NSLog(@"Movinf");
		
		newCenter.x = self.originalCenter.x + (newlocation.x - self.startLocation.x);
		newCenter.y = self.originalCenter.y + (newlocation.y - self.startLocation.y);
		
		DDAnnotation *theAnnotation = (DDAnnotation *)[self.mapView.annotations objectAtIndex:0];
        CLLocationCoordinate2D newCoordinate = [self.mapView convertPoint:newCenter toCoordinateFromView:self.view];
        [theAnnotation setCoordinate:newCoordinate];
        //NSLog(@"%f,%f", newCoordinate.latitude, newCoordinate.longitude);
        
        newLocation = newCoordinate;
        [self loadRoute];

        
	} else {
		// Let the parent class handle it.
		[super touchesMoved:touches withEvent:event];
	}
    
    UITouch *touch = [touches anyObject];
    CGPoint point = [touch locationInView:self.view];
    end = point;
    [self drawLine:start endpoint:end];
    
}*/


/*- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchLocation = [touch locationInView:self.view];
    
    if (CGRectContainsPoint(m_object.frame, touchLocation)) {
        
        dragging = YES;
        oldX = touchLocation.x;
        oldY = touchLocation.y;
    }
}

- (void)touchesMoved:(NSSet *)touches withEvent:(UIEvent *)event {
    
    UITouch *touch = [[event allTouches] anyObject];
    CGPoint touchLocation = [touch locationInView:self.view];
    
    if (dragging) {
        
        CGRect frame = m_object.frame;
        frame.origin.x = m_object.frame.origin.x + touchLocation.x - oldX;
        frame.origin.y =  m_object.frame.origin.y + touchLocation.y - oldY;
        m_object.frame = frame;
    }
}

- (void)touchesEnded:(NSSet *)touches withEvent:(UIEvent *)event {
    
    dragging = NO;
}*/



@end
