//
//  ICloudController.h
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MTICloudImagesIncludes.h"

@interface MTICloudImagesController : NSObject<MTICloudFileOpenViewControllerDelegate>

@property (copy, nonatomic) OpenICloudImageCompletion openCompletionBlock;

// Check if iCloud is enabled on the user's device
+(BOOL)isICloudEnabled;

// Presents the open image dialogue and when done passes the selected image to the block
-(void)openImageWithBlock:(OpenICloudImageCompletion)completion inViewController:(UIViewController*)viewController;

// Saves the supplied image to iCloud and calls back the delegate
-(void)saveImage:(UIImage*) img withDelegate:(id<MTICloudImagesControllerSaveDelegate>)saveDelegate;

@end