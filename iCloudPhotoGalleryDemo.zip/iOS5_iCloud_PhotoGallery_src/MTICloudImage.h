//
//  CloudImage.h
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MTICloudImage : UIDocument

@property (retain, nonatomic) UIImage* image;
@property (retain, nonatomic) NSString* fileName;
@property (assign, nonatomic) BOOL isOpening;

@end
