//
//  ICloudSaveImageButton.m
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import "MTICloudSaveImageButton.h"
#import "MTICloudImagesController.h"

@implementation MTICloudSaveImageButton

@synthesize completionBlock;

+(MTICloudSaveImageButton*)buttonWithBlock:(SaveICloudImageCompletion)completion
{
    MTICloudSaveImageButton* b = [MTICloudSaveImageButton buttonWithType:UIButtonTypeCustom];
    if (b != nil) {
        UIImage* loadImage = [UIImage imageNamed:@"saveBtnCloud.png"];
        [b setImage:loadImage forState:UIControlStateNormal];
        b.frame = CGRectMake(0, 0, loadImage.size.width, loadImage.size.height);
        [b addTarget:b action:@selector(tapped) forControlEvents:UIControlEventTouchUpInside];
        b.completionBlock = completion;
    }
    return b;
}

+(MTICloudSaveImageButton*)buttonAtPosition:(CGPoint)pos withBlock:(SaveICloudImageCompletion)completion
{
    MTICloudSaveImageButton* b = [self buttonWithBlock: completion];
    if (b != nil) {
        b.center = pos;
    }
    return b;
}

-(void)tapped
{
    //check for iCloud availability
    if ([MTICloudImagesController isICloudEnabled]==NO) {
        [[[UIAlertView alloc] initWithTitle:@"iCloud unavailable" 
                                    message:@"To use iCloud turn it on from your device's settings" 
                                   delegate:nil 
                          cancelButtonTitle:@"Close" 
                          otherButtonTitles: nil] show];
        
        NSError* e = [NSError errorWithDomain:@"iCloudImagesDomain" 
                                         code:1 
                                     userInfo:[NSDictionary dictionaryWithObject:@"iCloud not enabled" forKey:@"message"]
                      ];
        self.completionBlock(e);
        return;
    }
    
    self.completionBlock(nil);
}

-(MTICloudSaveImageButton*)animate
{    [UIView animateWithDuration:1.7 
                           delay:0.1 
                         options:UIViewAnimationOptionAllowUserInteraction |  UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionRepeat |  UIViewAnimationOptionAutoreverse
                      animations:^{
                          //animation code
                          self.center = CGPointMake(self.center.x, self.center.y-10);
                          
                      } completion:^(BOOL finished) {
                          //completion code
                          
                      }];
    return self;
}

-(void)dealloc
{
    self.completionBlock = nil;
}


@end
