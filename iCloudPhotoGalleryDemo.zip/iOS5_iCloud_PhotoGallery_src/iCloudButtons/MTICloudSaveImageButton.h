//
//  ICloudSaveImageButton.h
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTICloudImagesIncludes.h"

@interface MTICloudSaveImageButton : UIButton

@property (copy, nonatomic) SaveICloudImageCompletion completionBlock;

//methods to create an iCloud save button
+(MTICloudSaveImageButton*)buttonWithBlock:(SaveICloudImageCompletion)completion;
+(MTICloudSaveImageButton*)buttonAtPosition:(CGPoint)pos withBlock:(SaveICloudImageCompletion)completion;

//makes the button float
-(MTICloudSaveImageButton*)animate;

//called when the button was tapped
-(void)tapped;

@end
