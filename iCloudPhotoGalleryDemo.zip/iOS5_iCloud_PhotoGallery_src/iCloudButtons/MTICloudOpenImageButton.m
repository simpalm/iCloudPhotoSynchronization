//
//  ICloudOpenImageButton.m
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import "MTICloudOpenImageButton.h"
#import "MTICloudImagesController.h"

@implementation MTICloudOpenImageButton

@synthesize completionBlock;

+(MTICloudOpenImageButton*)buttonWithBlock:(OpenICloudImageCompletion)completion
{
    MTICloudOpenImageButton* b = [MTICloudOpenImageButton buttonWithType:UIButtonTypeCustom];
    if (b != nil) {
        UIImage* loadImage = [UIImage imageNamed:@"loadBtnCloud.png"];
        [b setImage:loadImage forState:UIControlStateNormal];
        b.frame = CGRectMake(0, 0, loadImage.size.width, loadImage.size.height);
        [b addTarget:b action:@selector(tapped) forControlEvents:UIControlEventTouchUpInside];
        b.completionBlock = completion;
    }
    return b;
}

+(MTICloudOpenImageButton*)buttonAtPosition:(CGPoint)pos withBlock:(OpenICloudImageCompletion)completion
{
    MTICloudOpenImageButton* b = [self buttonWithBlock: completion];
    if (b != nil) {
        b.center = pos;
    }
    return b;
}

-(void)tapped
{
    //check for iCloud availability
    if ([MTICloudImagesController isICloudEnabled]==NO) {
        [[[UIAlertView alloc] initWithTitle:@"iCloud unavailable" 
                                  message:@"To use iCloud turn it on from your device's settings" 
                                 delegate:nil 
                        cancelButtonTitle:@"Close" 
                        otherButtonTitles: nil] show];
        return;
    }

    [[[MTICloudImagesController alloc] init] openImageWithBlock:^(UIImage *image, NSError *error) {

        //image opened
        self.completionBlock(image, nil);
        
    } inViewController:self.window.rootViewController];
    
}

-(MTICloudOpenImageButton*)animate
{    [UIView animateWithDuration:1.7 
                          delay:0.1 
                        options:UIViewAnimationOptionAllowUserInteraction |  UIViewAnimationOptionBeginFromCurrentState | UIViewAnimationOptionRepeat |  UIViewAnimationOptionAutoreverse
                     animations:^{
                         //animation code
                         self.center = CGPointMake(self.center.x, self.center.y-10);
                         
                     } completion:^(BOOL finished) {
                         //completion code
                         
                     }];
    return self;
}

-(void)dealloc
{
    self.completionBlock = nil;
}

@end