//
//  ICloudOpenImageButton.h
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTICloudImagesIncludes.h"

@interface MTICloudOpenImageButton : UIButton

@property (copy, nonatomic) OpenICloudImageCompletion completionBlock;

//methods to create an iCloud open button
+(MTICloudOpenImageButton*)buttonWithBlock:(OpenICloudImageCompletion)completion;
+(MTICloudOpenImageButton*)buttonAtPosition:(CGPoint)pos withBlock:(OpenICloudImageCompletion)completion;

//makes the button float
-(MTICloudOpenImageButton*)animate;

//called when the button was tapped by the user
-(void)tapped;

@end
