//
//  ICloudController.m
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import "MTICloudImagesController.h"
#import "MTICloudImage.h"
#import "MTICloudFileOpenViewController.h"
#import "UIImage+Resize.h"

@implementation MTICloudImagesController

@synthesize openCompletionBlock;

#pragma mark - iCloud availability

+(NSInteger)getSystemVersionAsAnInteger
{
    int index = 0;
    NSInteger version = 0;
    
    NSArray* digits = [[UIDevice currentDevice].systemVersion componentsSeparatedByString:@"."];
    NSEnumerator* enumer = [digits objectEnumerator];
    NSString* number;
    while (number = [enumer nextObject]) {
        if (index>2) {
            break;
        }
        NSInteger multipler = powf(100, 2-index);
        version += [number intValue]*multipler;
        index++;
    }
    return version;
}

+(BOOL)isICloudEnabled
{
    //in iOS prior to 5.0 there's no iCloud
    if ([self getSystemVersionAsAnInteger] < 50000) {
        return NO;
    }
    
    //check iCloud availability
    NSURL *ubiq = [[NSFileManager defaultManager] URLForUbiquityContainerIdentifier:nil];
    return (ubiq)? YES:NO;
}

#pragma mark - Open images from iCloud
-(void)openImageWithBlock:(OpenICloudImageCompletion)completion inViewController:(UIViewController*)viewController
{
    //open the image open controller
    MTICloudFileOpenViewController* openFile = [[MTICloudFileOpenViewController alloc] initWithNibName:@"ICloudFileOpenViewController" bundle:[NSBundle mainBundle]];
    openFile.openDelegate = (id)self;
    [viewController presentViewController: openFile animated:YES completion:nil];
    self.openCompletionBlock = completion;
}

-(void)cancelledOpenImageFromCloudWithDialogue:(MTICloudFileOpenViewController *)dialogue
{
    [dialogue.presentingViewController dismissViewControllerAnimated:YES completion:^{
        self.openCompletionBlock(nil, nil);
    }];
}

-(void)openImageFromCloud:(UIImage *)cloudImage fromDialogue:(MTICloudFileOpenViewController *)dialogue
{
    [dialogue.presentingViewController dismissViewControllerAnimated:YES completion:^{
        self.openCompletionBlock(cloudImage, nil);
    }];
}

#pragma mark - Save images from iCloud
-(void)saveImage:(UIImage*) img withDelegate:(id<MTICloudImagesControllerSaveDelegate>)saveDelegate
{
    NSURL *ubiq = [[NSFileManager defaultManager] URLForUbiquityContainerIdentifier:nil];
    
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"yyyyMMddhhmmss"];
    
    NSString *fileName = [NSString stringWithFormat:@"Image_%@.png", 
                          [formatter stringFromDate:[NSDate date]]];
    NSLog(@"file name: %@", fileName);
    NSURL *ubiquitousPackage = [[ubiq URLByAppendingPathComponent:@"Documents"] 
                                URLByAppendingPathComponent:fileName];
    
    NSString *fileNameThumb = [NSString stringWithFormat:@"Image_%@_thumb.png",
                          [formatter stringFromDate:[NSDate date]]];
    NSURL *ubiquitousThumb = [[ubiq URLByAppendingPathComponent:@"Documents"] 
                                URLByAppendingPathComponent:fileNameThumb];

    
    MTICloudImage *doc = [[MTICloudImage alloc] initWithFileURL:ubiquitousPackage];
    doc.image = [img copy];
        
    [doc saveToURL:[doc fileURL] forSaveOperation:UIDocumentSaveForCreating completionHandler:^(BOOL success) {
        
        if (success) {
            //image saved to the cloud
            dispatch_async(dispatch_get_main_queue(), ^{
                
                MTICloudImage *docThumb = [[MTICloudImage alloc] initWithFileURL:ubiquitousThumb];
                docThumb.image = [doc.image resizedImageWithContentMode: UIViewContentModeScaleAspectFit 
                                                                 bounds: CGSizeMake(70, 70) 
                                                   interpolationQuality: kCGInterpolationMedium];
                [docThumb saveToURL:[docThumb fileURL] forSaveOperation:UIDocumentSaveForCreating completionHandler:^(BOOL success) {
                    docThumb.image=nil;
                    [saveDelegate savedToICloud:nil];
                }];
                
                doc.image = nil;
            });
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                doc.image = nil;
                NSError* e = [NSError errorWithDomain:@"iCloudImagesDomain" code:2 userInfo:[NSDictionary dictionaryWithObject:@"Saving to iCloud failed" forKey:@"message"]];
                [saveDelegate savedToICloud:e];
            });
        }
        
    }];
}

-(void)dealloc
{
    self.openCompletionBlock = nil;
}

@end
