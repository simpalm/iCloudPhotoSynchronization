//
//  ICloudImages.h
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import <Foundation/Foundation.h>

//one-shot-include for all the classes in the library

#import "MTICloudImagesIncludes.h"
#import "MTICloudImage.h"
#import "MTICloudImagesController.h"
#import "MTICloudFileOpenViewController.h"
#import "MTICloudOpenImageButton.h"
#import "MTICloudSaveImageButton.h"