//
//  ICloudFileOpenViewController.m
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import "MTICloudFileOpenViewController.h"
#import "MTICloudImagesIncludes.h"
#import "UIImage+Resize.h"
#import "QuartzCore/QuartzCore.h"

#import "MTICloudImage.h"

@implementation MTICloudFileOpenViewController

@synthesize files, query, openDelegate, loader;

- (id)initWithStyle:(UITableViewStyle)style
{
    self = [super initWithStyle:style];
    if (self) {
        // Custom initialization
        hasLoadedFiles = NO;
        noFilesFound = NO;
        hasFinishedLoading = NO;
        alert1 = nil;
    }
    return self;
}

- (void)loadFiles {
    
    NSURL *ubiq = [[NSFileManager defaultManager] URLForUbiquityContainerIdentifier:nil];
    
    if (ubiq) {
        
        Class metaDataQuery = NSClassFromString(@"NSMetadataQuery");
        if (metaDataQuery != nil) {
        
            self.query = [[metaDataQuery alloc] init];
            [self.query setSearchScopes:[NSArray arrayWithObject:NSMetadataQueryUbiquitousDocumentsScope]];
            NSPredicate *pred = [NSPredicate predicateWithFormat: @"%K ENDSWITH '_thumb.png'", NSMetadataItemFSNameKey];
            [self.query setPredicate:pred];
            [[NSNotificationCenter defaultCenter] addObserver:self 
                                                     selector:@selector(queryDidFinishGathering:) 
                                                         name:NSMetadataQueryDidFinishGatheringNotification 
                                                       object:self.query];
            [[NSNotificationCenter defaultCenter] addObserver:self 
                                                     selector:@selector(queryProgress:) 
                                                         name:NSMetadataQueryGatheringProgressNotification 
                                                       object:nil];
            [self.query startQuery];
        }
        
    } else {
        NSLog(@"No iCloud access");
    }
}

- (void)loadData:(id)query1 {
    
    [self.files removeAllObjects];
    
    if ([query1 results].count == 0) {
        noFilesFound = YES;
        [self.tableView reloadData];
        self.query = nil;
        return;
    }
    
    NSArray* results = [query1 results];
    
    for (int i=0;i<results.count;i++) {
        NSMetadataItem* item = [results objectAtIndex:i];
        NSURL *url = [item valueForAttribute:NSMetadataItemURLKey];
        MTICloudImage *doc = [[MTICloudImage alloc] initWithFileURL:url];

        hasLoadedFiles = YES;
        [self.files addObject:doc];

        if ( self.files.count == results.count ) {
            hasFinishedLoading = YES;
            [self.loader setHidden:YES];
            [self.loader stopAnimating];
            [self.files sortUsingSelector: @selector(compare:) ];
            [self.tableView reloadData];
        }
    }
    
   self.query = nil;
} 

- (void)queryProgress:(NSNotification *)notification {
    //
}

- (void)queryDidFinishGathering:(NSNotification *)notification {
    //

    Class metaDataQuery = NSClassFromString(@"NSMetadataQuery");
    if (metaDataQuery != nil) {
        
        NSMetadataQuery *query1 = [notification object];
        [query1 disableUpdates];
        [query1 stopQuery];
        
        [self loadData:query1];
        
        [[NSNotificationCenter defaultCenter] removeObserver:self 
                                                        name:NSMetadataQueryDidFinishGatheringNotification
                                                      object:query1];
    }
}

#pragma mark - View lifecycle
- (void)viewDidLoad
{
    [super viewDidLoad];

    self.files = [NSMutableArray array];
    [self loadFiles];
}

- (void)viewDidUnload
{
    for (MTICloudImage* file in self.files) {
        [file closeWithCompletionHandler:nil];
    }
    
    self.query = nil;
    self.files = nil;
    self.openDelegate = nil;

    [super viewDidUnload];
}

- (void)viewWillDisappear:(BOOL)animated
{
    if (alert1 != nil) {
        [alert1 dismissWithClickedButtonIndex:0 animated:NO];
        [alert1 removeFromSuperview];
        alert1 = nil;
    }
    
    [super viewWillDisappear:animated];
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortrait);
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {return 1;}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (hasLoadedFiles==NO || noFilesFound==YES){
        return 1;
    }
    
    return [self.files count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (noFilesFound==YES) {
        cell.textLabel.text = @"No files found";
        [self.loader performSelector:@selector(stopAnimating) withObject:nil afterDelay:1.0];
        return cell;
    }
    
    if (hasLoadedFiles==NO){
        cell.textLabel.text = @"Loading, please wait ...";
        return cell;
    }
    
    if (cell.imageView.image!=nil) return cell;
    
    MTICloudImage * file = [self.files objectAtIndex:indexPath.row];
    //NSLog(@"cell %i file %@", indexPath.row, [file fileName]);
    
    if (file.isOpening) return cell;
    
    file.isOpening = YES;
    [file openWithCompletionHandler:^(BOOL success) {
         if (success) {
             cell.imageView.image = file.image;

             cell.imageView.bounds = CGRectMake(cell.imageView.bounds.origin.x, 
                                           cell.imageView.bounds.origin.y, 
                                           70, 70);
             cell.imageView.center = CGPointMake(cell.imageView.center.x+10, cell.imageView.center.y);
             
             cell.imageView.layer.cornerRadius = 5.0;
             cell.imageView.clipsToBounds = YES;

             NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
             [formatter setDateStyle:NSDateFormatterMediumStyle];
             [formatter setTimeStyle:NSDateFormatterShortStyle];
             [formatter setLocale:[NSLocale currentLocale]];
                          
             NSString *stringFromDate = [formatter stringFromDate:file.fileModificationDate];
             
             cell.textLabel.text = stringFromDate;
             cell.textLabel.numberOfLines = 2;

             cell.textLabel.center = CGPointMake(cell.textLabel.center.x+10, cell.textLabel.center.y);
             cell.textLabel.font = [UIFont fontWithName:@"Trebuchet MS" size:16.0];

             [file closeWithCompletionHandler:^(BOOL success) {
              file.isOpening = NO;
             }];

             [cell setNeedsDisplay];
             [self.tableView reloadData];

         } else {
             NSLog(@"failed to open from iCloud");
         }
    }];
    
    
    return cell;
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section 
{
    UIView* header = [[UIView alloc] initWithFrame: CGRectMake(0, 0, 300, 80)];
    
    UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(20, 0, 200, 50)];
    label.text = @"iCloud files";
    label.textColor = [UIColor grayColor];
    label.shadowColor = [UIColor whiteColor];
    label.shadowOffset = CGSizeMake(-1, -1);
    label.font = [UIFont fontWithName:@"Trebuchet MS" size:24.0];
    label.backgroundColor = [UIColor clearColor];
    [header addSubview:label];
    
    if (hasFinishedLoading==NO) {
        UIActivityIndicatorView* l = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge];
        l.frame = CGRectMake(180, 9, 40, 40);
        if (noFilesFound==NO) {
            [l startAnimating];
        }
        [header addSubview: l];
        self.loader = l;
    }
    
    UIButton* back = [UIButton buttonWithType:UIButtonTypeCustom];
    [back setTitle:@"Close" forState:UIControlStateNormal];
    back.titleLabel.textColor = [UIColor blackColor];
    back.frame = CGRectMake(230, 9, 70, 40);
    [back addTarget:self action:@selector(closeController) forControlEvents:UIControlEventTouchUpInside];
    
    [header addSubview: back];
    
    return header;
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section
{
    if (hasFinishedLoading==NO) return nil;
    
    UIView* footer = [[UIView alloc] initWithFrame: CGRectMake(0, 0, 300, 80)];
    
    UILabel* label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 300, 30)];
    label.text = [NSString stringWithFormat: @"%i files", [self.files count]];
    label.textColor = [UIColor grayColor];
    label.textAlignment = UITextAlignmentCenter;
    label.font = [UIFont fontWithName:@"Trebuchet MS" size:14.0];
    label.backgroundColor = [UIColor clearColor];
    [footer addSubview:label];

    return footer;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    return 60;
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section
{
    return 40;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 92;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (hasLoadedFiles==NO) return;
    
    if (noFilesFound==YES) {
        [self.openDelegate cancelledOpenImageFromCloudWithDialogue: self];
        return;
    }
    
    alert1 = [[UIAlertView alloc] initWithTitle:@"iCloud" 
                                         message:@"Loading file..." 
                                        delegate:self cancelButtonTitle:nil otherButtonTitles:nil];
    UIActivityIndicatorView* loaderView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleWhiteLarge]; 
    loaderView.frame = CGRectMake(120, 75, 40, 40);
    [loaderView startAnimating];
    [alert1 addSubview: loaderView];
    [alert1 show];
    
    [self performSelector:@selector(openCloudFile:) withObject:[self.files objectAtIndex:indexPath.row] afterDelay:0.1];
}

-(void)openCloudFile:(MTICloudImage*)img
{
    NSURL* fullImageURL = [NSURL URLWithString: [[img.fileURL description] stringByReplacingOccurrencesOfString:@"_thumb." withString:@"."] ];
    MTICloudImage* fullImage = [[MTICloudImage alloc] initWithFileURL: fullImageURL];
    [fullImage openWithCompletionHandler:^(BOOL success) {
        //image is opened
        UIImage* fullImageRotated = [[UIImage alloc] initWithCGImage:fullImage.image.CGImage scale:1.0 orientation:[fullImage.image imageOrientation]];
        [self.openDelegate openImageFromCloud:fullImageRotated fromDialogue:self];
    }];
}

-(void)closeController
{
    [self.query disableUpdates];
    [self.query stopQuery];
    [self.files removeAllObjects];
    [self.openDelegate cancelledOpenImageFromCloudWithDialogue:self];
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (noFilesFound==YES) return;
    
    MTICloudImage* deleteImage = [self.files objectAtIndex:indexPath.row];

    //bail out if still opening
    if (deleteImage.isOpening) return;
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        // Delete the row from the data source
        
            NSFileManager* fm = [NSFileManager defaultManager];
            NSError* err;
            BOOL stat = [fm removeItemAtURL: deleteImage.fileURL  error: &err];
            if (stat==NO) {
                //could not delete the file from the cloud
                //files still in the cloud
                [[[UIAlertView alloc] initWithTitle:@"Error" 
                                           message:@"The file cannot be deleted from iCloud right now, try closing it on all your devices first" 
                                          delegate:nil 
                                 cancelButtonTitle:@"Close" 
                                 otherButtonTitles: nil] show];
                return;
                
            } else {
                //delete also the full image
                NSURL* fullImageURL = [NSURL URLWithString: [[deleteImage.fileURL description] stringByReplacingOccurrencesOfString:@"_thumb." withString:@"." ]];
                BOOL statFull = [fm removeItemAtURL: fullImageURL error: &err];
                if (statFull==NO) {
                    //weird problem, delete manually
                    [[[UIAlertView alloc] initWithTitle:@"Error" 
                                               message:@"The file cannot be deleted from iCloud. You can try deleting the file manually from outside the app" 
                                              delegate:nil 
                                     cancelButtonTitle:@"Close" 
                                     otherButtonTitles: nil] show];
                    return;
                }
                
                //thumb and full image are deleted, refresh the UI
                [self.files removeObject: deleteImage];
                [tableView deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:YES];
                [tableView reloadData];

            }
        
    }   
}


@end
