//
//  ICloudImagesIncludes.h
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

//macro for getting a background queue
#define kBgQueue dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)

//types for the blocks being passed around
typedef void(^OpenICloudImageCompletion)(UIImage* image, NSError* error);
typedef void(^SaveICloudImageCompletion)(NSError* error);

@class MTICloudFileOpenViewController;

//
// The delegate to the Open Image Dialogue should handle 
// the cases when the user cancels the process and when
// selects an image from their iCloud storage
//
@protocol MTICloudFileOpenViewControllerDelegate
@required

-(void)cancelledOpenImageFromCloudWithDialogue:(MTICloudFileOpenViewController*)dialogue;
-(void)openImageFromCloud:(UIImage*)cloudImage fromDialogue:(MTICloudFileOpenViewController*)dialogue;

@end

//
// The delegate to the ICloudImagesController should implement
// a method to handle the finishing of the saving process
// if error is nil the image was successfuly saved
//
@protocol MTICloudImagesControllerSaveDelegate
@required
-(void)savedToICloud:(NSError*)error;
@end