//
//  CloudImage.m
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import "MTICloudImage.h"

@implementation MTICloudImage

@synthesize image, fileName, isOpening;

- (BOOL)loadFromContents:(id)contents ofType:(NSString *)typeName error:(NSError **)outError
{
    if ([contents length] > 0) {
        self.image = [UIImage imageWithData: contents];
    } else {
        self.image = nil;
    }
    return YES;
}

- (id)contentsForType:(NSString *)typeName error:(NSError **)outError 
{
    if (self.image==nil) return nil;
    return UIImagePNGRepresentation(self.image);
}

-(NSString*)fileName
{
    return [self.fileURL lastPathComponent];
}

- (NSComparisonResult)compare:(MTICloudImage *)otherObject {
    return (-1) * [self.fileName compare:otherObject.fileName];
}

@end
