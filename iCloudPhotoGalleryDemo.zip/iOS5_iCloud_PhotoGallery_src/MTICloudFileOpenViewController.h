//
//  ICloudFileOpenViewController.h
//  PimpyRetinaProject
//
//  Created by Marin Todorov on 10/27/11.
//  Copyright (c) 2011 Underplot Apps. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTICloudImagesIncludes.h"

@interface MTICloudFileOpenViewController : UITableViewController <UIAlertViewDelegate>
{
    BOOL hasLoadedFiles;
    BOOL noFilesFound;
    BOOL hasFinishedLoading;
    
    UIActivityIndicatorView* loader;
    UIAlertView* alert1;
}

@property (strong) NSMutableArray* files;
@property (strong) id query;
@property (strong) id<MTICloudFileOpenViewControllerDelegate> openDelegate;

@property (strong) UIActivityIndicatorView* loader;

@end
