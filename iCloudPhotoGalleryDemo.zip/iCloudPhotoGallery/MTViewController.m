//
//  MTViewController.m
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import "MTViewController.h"
#import "UIImage+Resize.h"

@implementation MTViewController

#pragma mark - Setup the User Interface
- (void)viewDidLoad
{
    [super viewDidLoad];
    
    //
    // Add open from iCloud button, the supplied block will be executed when the user has already selected 
    // an image from iCloud and the selected image is provided to the block
    //
    [self.view addSubview:
        [[MTICloudOpenImageButton buttonAtPosition: CGPointMake(150, 150) withBlock:^(UIImage *image, NSError *error) {
            //code to handle the image from iCloud
            loadImageView.image = image;
        }] animate]
     ];
    
    //
    // Add save to iCloud button, the block is executed when the user taps the save button, the block has to fetch the image to be saved
    // and then call ICloudImagesController to save the image, upon finishing the saving process the 
    //
    [self.view addSubview:
     [[MTICloudSaveImageButton buttonAtPosition: CGPointMake(150, 380) withBlock:^(NSError *error) {
            //code
            if (error==nil && saveImageView.image!=nil) {
                //save to iCloud
                [[[MTICloudImagesController alloc] init] saveImage: saveImageView.image withDelegate:(id)self];
            }
        }] animate]
     ];
}

#pragma mark - Standard code to make photos with the camera
-(IBAction)takePhoto:(id)sender
{
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
	imagePickerController.editing = YES;
    imagePickerController.delegate = (id)self;
    
    [self presentViewController:imagePickerController animated:YES completion:nil];
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingImage:(UIImage *)image editingInfo:(NSDictionary *)editingInfo
{
    saveImageView.image = [image resizedImage:image.size interpolationQuality: kCGInterpolationHigh];
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - ICloudImagesControllerSaveDelegate methods
-(void)savedToICloud:(NSError*)error
{
    NSString* message= (error==nil)? @"Your photo was saved":@"Error saving your photo, try again later?" ;

    [[[UIAlertView alloc] initWithTitle:@"iCloud message" 
                                message:message
                               delegate:nil 
                      cancelButtonTitle:@"Close" 
                      otherButtonTitles:nil] show];
    saveImageView.image = nil;
}

@end