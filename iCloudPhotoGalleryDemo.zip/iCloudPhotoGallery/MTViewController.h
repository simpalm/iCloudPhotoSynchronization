//
//  MTViewController.h
//  iCloudPhotoGallery
//
//  Created by Marin Todorov on 11/25/11.
//  Copyright (c) 2011 Marin Todorov. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MTICloudImages.h"

@interface MTViewController : UIViewController<UIImagePickerControllerDelegate, MTICloudImagesControllerSaveDelegate>
{
    IBOutlet UIImageView* loadImageView;
    IBOutlet UIImageView* saveImageView;
}

-(IBAction)takePhoto:(id)sender;

@end
